﻿namespace _4._Border_Control
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            string specificYear;
            string[] inp = Console.ReadLine().Split(" ");
            List<Ibirthable> citizenInfo = new List<Ibirthable>();
            List<Ibirthable> petInfo = new List<Ibirthable>();
            List<IDentifialeC> robotinfo = new List<IDentifialeC>();
           

            while (inp[0] != "End") 
            {
                if (inp[0] == "Citizen")
                {
                    Citizens citizen = new Citizens();
                    citizen.Name = inp[1];
                    citizen.Age = int.Parse(inp[2]);                 
                    citizen.Id = inp[3];
                    citizen.Birthday = inp[4];

                    citizenInfo.Add(citizen);
                }
                else if(inp[0] == "Pet")
                {
                    Pet pet = new Pet();
                    pet.Name = inp[1];
                    pet.Birthday = inp[2];
                    petInfo.Add(pet);
                }
                else if (inp[0] == "Robot")
                {
                    Robots robot = new Robots();
                    robot.Model = inp[1];
                    robot.Id = inp[2];
                    robotinfo.Add(robot);
                }
                
                inp = Console.ReadLine().Split(" ");
            }

            specificYear = Console.ReadLine();
            foreach (var citizen in citizenInfo)
            {
                if (citizen.Birthday.EndsWith(specificYear))
                {
                    Console.WriteLine(citizen.Birthday);
                }
            }
            foreach (var pet in petInfo)
            {
                if (pet.Birthday.EndsWith(specificYear))
                {
                    Console.WriteLine(pet.Birthday);
                }
            }

        }
    }

}
