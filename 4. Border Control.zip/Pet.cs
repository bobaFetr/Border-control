﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4._Border_Control
{
    public  class Pet : Ibirthable
    {
        public string Type { get; set; }
        public string Birthday { get; set; }
        public string Name { get; set; }
        public Pet(string name, string birthday) 
        { 
            Name = name;
            Birthday = birthday;
           
        }

        public Pet() { }
    }
}
